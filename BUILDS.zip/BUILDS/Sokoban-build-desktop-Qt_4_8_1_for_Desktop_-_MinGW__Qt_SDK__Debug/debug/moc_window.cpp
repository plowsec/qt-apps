/****************************************************************************
** Meta object code from reading C++ file 'window.h'
**
** Created: Wed 25. Jul 20:11:17 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Sokoban/window.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'window.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Window[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       8,    7,    7,    7, 0x08,
      20,    7,    7,    7, 0x08,
      37,    7,    7,    7, 0x08,
      67,   63,    7,    7, 0x08,
      85,   63,    7,    7, 0x08,
     115,    7,  111,    7, 0x08,
     125,    7,  111,    7, 0x08,
     135,   63,    7,    7, 0x08,
     159,   63,    7,    7, 0x08,
     180,    7,  111,    7, 0x08,
     193,    7,  111,    7, 0x08,
     208,  206,    7,    7, 0x08,
     223,    7,  111,    7, 0x08,
     235,  232,    7,    7, 0x08,
     254,    7,    7,    7, 0x08,
     267,    7,    7,    7, 0x08,
     281,    7,  111,    7, 0x08,
     298,    7,    7,    7, 0x08,
     321,    7,    7,    7, 0x08,
     346,    7,    7,    7, 0x08,
     360,    7,    7,    7, 0x08,
     367,    7,    7,    7, 0x08,
     379,    7,    7,    7, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Window[] = {
    "Window\0\0buildMenu()\0buildInterface()\0"
    "keyPressEvent(QKeyEvent*)\0x,y\0"
    "setPosXY(int,int)\0setRelativePosXY(int,int)\0"
    "int\0getPosX()\0getPosY()\0deplacerJoueur(int,int)\0"
    "setOldPosXY(int,int)\0getOldPosX()\0"
    "getOldPosY()\0c\0setNiveau(int)\0getLvl()\0"
    "ch\0chargerNiveau(int)\0execEditor()\0"
    "recommencer()\0compterNiveaux()\0"
    "chargerNiveauSuivant()\0chargerNiveauPrecedent()\0"
    "execOptions()\0aide()\0setGraphs()\0"
    "annuler()\0"
};

void Window::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Window *_t = static_cast<Window *>(_o);
        switch (_id) {
        case 0: _t->buildMenu(); break;
        case 1: _t->buildInterface(); break;
        case 2: _t->keyPressEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        case 3: _t->setPosXY((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->setRelativePosXY((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 5: { int _r = _t->getPosX();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 6: { int _r = _t->getPosY();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 7: _t->deplacerJoueur((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 8: _t->setOldPosXY((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 9: { int _r = _t->getOldPosX();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 10: { int _r = _t->getOldPosY();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 11: _t->setNiveau((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: { int _r = _t->getLvl();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 13: _t->chargerNiveau((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->execEditor(); break;
        case 15: _t->recommencer(); break;
        case 16: { int _r = _t->compterNiveaux();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 17: _t->chargerNiveauSuivant(); break;
        case 18: _t->chargerNiveauPrecedent(); break;
        case 19: _t->execOptions(); break;
        case 20: _t->aide(); break;
        case 21: _t->setGraphs(); break;
        case 22: _t->annuler(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Window::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Window::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Window,
      qt_meta_data_Window, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Window::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Window::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Window::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Window))
        return static_cast<void*>(const_cast< Window*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int Window::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
