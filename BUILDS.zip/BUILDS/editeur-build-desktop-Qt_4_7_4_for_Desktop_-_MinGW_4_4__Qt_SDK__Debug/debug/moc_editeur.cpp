/****************************************************************************
** Meta object code from reading C++ file 'editeur.h'
**
** Created: Mon 26. Dec 14:21:01 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../editeur/editeur.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'editeur.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Editeur[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x08,
      26,    8,    8,    8, 0x08,
      39,    8,    8,    8, 0x08,
      58,    8,    8,    8, 0x08,
      79,    8,    8,    8, 0x08,
      96,    8,    8,    8, 0x08,
     113,    8,    8,    8, 0x08,
     131,    8,    8,    8, 0x08,
     152,    8,    8,    8, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Editeur[] = {
    "Editeur\0\0buildInterface()\0buildEcran()\0"
    "changeEtatCaisse()\0changeEtatCaisseOk()\0"
    "changeEtatSand()\0changeEtatWall()\0"
    "changeEtatMario()\0changeEtatObjectif()\0"
    "save()\0"
};

const QMetaObject Editeur::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Editeur,
      qt_meta_data_Editeur, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Editeur::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Editeur::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Editeur::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Editeur))
        return static_cast<void*>(const_cast< Editeur*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int Editeur::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: buildInterface(); break;
        case 1: buildEcran(); break;
        case 2: changeEtatCaisse(); break;
        case 3: changeEtatCaisseOk(); break;
        case 4: changeEtatSand(); break;
        case 5: changeEtatWall(); break;
        case 6: changeEtatMario(); break;
        case 7: changeEtatObjectif(); break;
        case 8: save(); break;
        default: ;
        }
        _id -= 9;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
