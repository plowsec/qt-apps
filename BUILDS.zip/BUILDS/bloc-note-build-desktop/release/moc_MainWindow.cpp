/****************************************************************************
** Meta object code from reading C++ file 'MainWindow.h'
**
** Created: Sun 18. Dec 21:06:18 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../bloc-note/MainWindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x0a,
      30,   11,   11,   11, 0x0a,
      42,   11,   11,   11, 0x0a,
      60,   11,   11,   11, 0x0a,
      71,   11,   11,   11, 0x0a,
      79,   11,   11,   11, 0x0a,
      95,   11,   11,   11, 0x0a,
     126,  119,   11,   11, 0x0a,
     157,  150,   11,   11, 0x0a,
     182,   11,   11,   11, 0x0a,
     198,   11,   11,   11, 0x0a,
     216,   11,   11,   11, 0x0a,
     234,   11,   11,   11, 0x0a,
     252,   11,   11,   11, 0x0a,
     263,   11,   11,   11, 0x0a,
     278,   11,   11,   11, 0x0a,
     294,   11,   11,   11, 0x0a,
     306,   11,   11,   11, 0x0a,
     324,   11,   11,   11, 0x0a,
     339,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0nouveauDocument()\0ouvrirDoc()\0"
    "enregistrerSous()\0saveFile()\0print()\0"
    "choisirPolice()\0changeBackGroundColor()\0"
    "police\0boxPoliceEnCours(QFont)\0taille\0"
    "taillePoliceEnCours(int)\0annulerAction()\0"
    "couperSelection()\0copierSelection()\0"
    "collerSelection()\0modeGras()\0"
    "modeItalique()\0modeSoulignge()\0"
    "execProgr()\0execProgrSecond()\0"
    "execProgrTer()\0execAbout()\0"
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: nouveauDocument(); break;
        case 1: ouvrirDoc(); break;
        case 2: enregistrerSous(); break;
        case 3: saveFile(); break;
        case 4: print(); break;
        case 5: choisirPolice(); break;
        case 6: changeBackGroundColor(); break;
        case 7: boxPoliceEnCours((*reinterpret_cast< const QFont(*)>(_a[1]))); break;
        case 8: taillePoliceEnCours((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 9: annulerAction(); break;
        case 10: couperSelection(); break;
        case 11: copierSelection(); break;
        case 12: collerSelection(); break;
        case 13: modeGras(); break;
        case 14: modeItalique(); break;
        case 15: modeSoulignge(); break;
        case 16: execProgr(); break;
        case 17: execProgrSecond(); break;
        case 18: execProgrTer(); break;
        case 19: execAbout(); break;
        default: ;
        }
        _id -= 20;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
