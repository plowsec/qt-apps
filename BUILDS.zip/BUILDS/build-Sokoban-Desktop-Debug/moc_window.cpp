/****************************************************************************
** Meta object code from reading C++ file 'window.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Sokoban/window.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'window.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Window_t {
    QByteArrayData data[30];
    char stringdata[307];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_Window_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_Window_t qt_meta_stringdata_Window = {
    {
QT_MOC_LITERAL(0, 0, 6),
QT_MOC_LITERAL(1, 7, 9),
QT_MOC_LITERAL(2, 17, 0),
QT_MOC_LITERAL(3, 18, 14),
QT_MOC_LITERAL(4, 33, 13),
QT_MOC_LITERAL(5, 47, 10),
QT_MOC_LITERAL(6, 58, 8),
QT_MOC_LITERAL(7, 67, 1),
QT_MOC_LITERAL(8, 69, 1),
QT_MOC_LITERAL(9, 71, 16),
QT_MOC_LITERAL(10, 88, 7),
QT_MOC_LITERAL(11, 96, 7),
QT_MOC_LITERAL(12, 104, 14),
QT_MOC_LITERAL(13, 119, 11),
QT_MOC_LITERAL(14, 131, 10),
QT_MOC_LITERAL(15, 142, 10),
QT_MOC_LITERAL(16, 153, 9),
QT_MOC_LITERAL(17, 163, 1),
QT_MOC_LITERAL(18, 165, 6),
QT_MOC_LITERAL(19, 172, 13),
QT_MOC_LITERAL(20, 186, 2),
QT_MOC_LITERAL(21, 189, 10),
QT_MOC_LITERAL(22, 200, 11),
QT_MOC_LITERAL(23, 212, 14),
QT_MOC_LITERAL(24, 227, 20),
QT_MOC_LITERAL(25, 248, 22),
QT_MOC_LITERAL(26, 271, 11),
QT_MOC_LITERAL(27, 283, 4),
QT_MOC_LITERAL(28, 288, 9),
QT_MOC_LITERAL(29, 298, 7)
    },
    "Window\0buildMenu\0\0buildInterface\0"
    "keyPressEvent\0QKeyEvent*\0setPosXY\0x\0"
    "y\0setRelativePosXY\0getPosX\0getPosY\0"
    "deplacerJoueur\0setOldPosXY\0getOldPosX\0"
    "getOldPosY\0setNiveau\0c\0getLvl\0"
    "chargerNiveau\0ch\0execEditor\0recommencer\0"
    "compterNiveaux\0chargerNiveauSuivant\0"
    "chargerNiveauPrecedent\0execOptions\0"
    "aide\0setGraphs\0annuler\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Window[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x08,
       3,    0,  130,    2, 0x08,
       4,    1,  131,    2, 0x08,
       6,    2,  134,    2, 0x08,
       9,    2,  139,    2, 0x08,
      10,    0,  144,    2, 0x08,
      11,    0,  145,    2, 0x08,
      12,    2,  146,    2, 0x08,
      13,    2,  151,    2, 0x08,
      14,    0,  156,    2, 0x08,
      15,    0,  157,    2, 0x08,
      16,    1,  158,    2, 0x08,
      18,    0,  161,    2, 0x08,
      19,    1,  162,    2, 0x08,
      21,    0,  165,    2, 0x08,
      22,    0,  166,    2, 0x08,
      23,    0,  167,    2, 0x08,
      24,    0,  168,    2, 0x08,
      25,    0,  169,    2, 0x08,
      26,    0,  170,    2, 0x08,
      27,    0,  171,    2, 0x08,
      28,    0,  172,    2, 0x08,
      29,    0,  173,    2, 0x08,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    7,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    7,    8,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    7,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    7,    8,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Int,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Window::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Window *_t = static_cast<Window *>(_o);
        switch (_id) {
        case 0: _t->buildMenu(); break;
        case 1: _t->buildInterface(); break;
        case 2: _t->keyPressEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        case 3: _t->setPosXY((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->setRelativePosXY((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 5: { int _r = _t->getPosX();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 6: { int _r = _t->getPosY();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 7: _t->deplacerJoueur((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 8: _t->setOldPosXY((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 9: { int _r = _t->getOldPosX();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 10: { int _r = _t->getOldPosY();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 11: _t->setNiveau((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: { int _r = _t->getLvl();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 13: _t->chargerNiveau((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->execEditor(); break;
        case 15: _t->recommencer(); break;
        case 16: { int _r = _t->compterNiveaux();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 17: _t->chargerNiveauSuivant(); break;
        case 18: _t->chargerNiveauPrecedent(); break;
        case 19: _t->execOptions(); break;
        case 20: _t->aide(); break;
        case 21: _t->setGraphs(); break;
        case 22: _t->annuler(); break;
        default: ;
        }
    }
}

const QMetaObject Window::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Window.data,
      qt_meta_data_Window,  qt_static_metacall, 0, 0}
};


const QMetaObject *Window::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Window::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Window.stringdata))
        return static_cast<void*>(const_cast< Window*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int Window::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
