/****************************************************************************
** Meta object code from reading C++ file 'Myframe.h'
**
** Created: Sun 22. Jan 18:21:45 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../bloc-note/Myframe.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Myframe.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MyFrame[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x08,
      21,    8,    8,    8, 0x08,
      36,    8,    8,    8, 0x08,
      52,    8,    8,    8, 0x08,
      67,    8,    8,    8, 0x08,
      84,    8,    8,    8, 0x08,
     108,   94,    8,    8, 0x08,
     133,    8,  125,    8, 0x08,
     143,    8,    8,    8, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MyFrame[] = {
    "MyFrame\0\0buildMenu()\0buildHorloge()\0"
    "updateHorloge()\0setAiguilles()\0"
    "clearAiguilles()\0setSong()\0cheminFichier\0"
    "setPath(QString)\0QString\0getPath()\0"
    "isTime()\0"
};

const QMetaObject MyFrame::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MyFrame,
      qt_meta_data_MyFrame, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyFrame::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyFrame::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyFrame::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyFrame))
        return static_cast<void*>(const_cast< MyFrame*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MyFrame::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: buildMenu(); break;
        case 1: buildHorloge(); break;
        case 2: updateHorloge(); break;
        case 3: setAiguilles(); break;
        case 4: clearAiguilles(); break;
        case 5: setSong(); break;
        case 6: setPath((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: { QString _r = getPath();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 8: isTime(); break;
        default: ;
        }
        _id -= 9;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
