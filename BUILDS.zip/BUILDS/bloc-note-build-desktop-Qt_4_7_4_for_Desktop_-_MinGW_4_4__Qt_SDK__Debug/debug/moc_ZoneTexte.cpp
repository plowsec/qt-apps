/****************************************************************************
** Meta object code from reading C++ file 'ZoneTexte.h'
**
** Created: Sun 22. Jan 18:21:15 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../bloc-note/ZoneTexte.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ZoneTexte.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ZoneTexte[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      17,   11,   10,   10, 0x0a,
      35,   10,   10,   10, 0x0a,
      60,   49,   10,   10, 0x0a,
      86,   10,   10,   10, 0x0a,
     110,   10,  102,   10, 0x0a,
     134,  127,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ZoneTexte[] = {
    "ZoneTexte\0\0titre\0setTitre(QString)\0"
    "enregistrer()\0nomFichier\0"
    "saveAlreadyExist(QString)\0imprimerTexte()\0"
    "QString\0getEmplacement()\0chemin\0"
    "setEmplacement(QString)\0"
};

const QMetaObject ZoneTexte::staticMetaObject = {
    { &QTextEdit::staticMetaObject, qt_meta_stringdata_ZoneTexte,
      qt_meta_data_ZoneTexte, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ZoneTexte::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ZoneTexte::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ZoneTexte::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ZoneTexte))
        return static_cast<void*>(const_cast< ZoneTexte*>(this));
    return QTextEdit::qt_metacast(_clname);
}

int ZoneTexte::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTextEdit::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: setTitre((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: enregistrer(); break;
        case 2: saveAlreadyExist((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: imprimerTexte(); break;
        case 4: { QString _r = getEmplacement();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 5: setEmplacement((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 6;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
