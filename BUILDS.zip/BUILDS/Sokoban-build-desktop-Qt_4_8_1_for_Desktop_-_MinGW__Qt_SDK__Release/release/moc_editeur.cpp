/****************************************************************************
** Meta object code from reading C++ file 'editeur.h'
**
** Created: Wed 25. Jul 18:53:05 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Sokoban/editeur.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'editeur.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Editeur[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x08,
      26,    8,    8,    8, 0x08,
      39,    8,    8,    8, 0x08,
      58,    8,    8,    8, 0x08,
      79,    8,    8,    8, 0x08,
      96,    8,    8,    8, 0x08,
     113,    8,    8,    8, 0x08,
     131,    8,    8,    8, 0x08,
     152,    8,    8,    8, 0x08,
     159,    8,    8,    8, 0x08,
     166,    8,    8,    8, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Editeur[] = {
    "Editeur\0\0buildInterface()\0buildEcran()\0"
    "changeEtatCaisse()\0changeEtatCaisseOk()\0"
    "changeEtatSand()\0changeEtatWall()\0"
    "changeEtatMario()\0changeEtatObjectif()\0"
    "save()\0aide()\0setGraphs()\0"
};

void Editeur::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Editeur *_t = static_cast<Editeur *>(_o);
        switch (_id) {
        case 0: _t->buildInterface(); break;
        case 1: _t->buildEcran(); break;
        case 2: _t->changeEtatCaisse(); break;
        case 3: _t->changeEtatCaisseOk(); break;
        case 4: _t->changeEtatSand(); break;
        case 5: _t->changeEtatWall(); break;
        case 6: _t->changeEtatMario(); break;
        case 7: _t->changeEtatObjectif(); break;
        case 8: _t->save(); break;
        case 9: _t->aide(); break;
        case 10: _t->setGraphs(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData Editeur::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Editeur::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Editeur,
      qt_meta_data_Editeur, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Editeur::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Editeur::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Editeur::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Editeur))
        return static_cast<void*>(const_cast< Editeur*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int Editeur::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
