/****************************************************************************
** Meta object code from reading C++ file 'options.h'
**
** Created: Wed 25. Jul 19:25:12 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Sokoban/options.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'options.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Options[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x08,
      26,    8,    8,    8, 0x08,
      34,    8,    8,    8, 0x08,
      47,    8,    8,    8, 0x08,
      68,    8,    8,    8, 0x08,
      87,    8,    8,    8, 0x08,
     102,    8,    8,    8, 0x08,
     116,    8,    8,    8, 0x08,
     133,    8,    8,    8, 0x08,
     152,    8,    8,    8, 0x08,
     169,    8,    8,    8, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Options[] = {
    "Options\0\0buildInterface()\0check()\0"
    "setNiveaux()\0setImagePersonnage()\0"
    "setImageObjectif()\0setImageFond()\0"
    "setImageMur()\0setImageCaisse()\0"
    "setImageCaisseOk()\0reglagesDefaut()\0"
    "setGraphs()\0"
};

void Options::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Options *_t = static_cast<Options *>(_o);
        switch (_id) {
        case 0: _t->buildInterface(); break;
        case 1: _t->check(); break;
        case 2: _t->setNiveaux(); break;
        case 3: _t->setImagePersonnage(); break;
        case 4: _t->setImageObjectif(); break;
        case 5: _t->setImageFond(); break;
        case 6: _t->setImageMur(); break;
        case 7: _t->setImageCaisse(); break;
        case 8: _t->setImageCaisseOk(); break;
        case 9: _t->reglagesDefaut(); break;
        case 10: _t->setGraphs(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData Options::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Options::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Options,
      qt_meta_data_Options, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Options::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Options::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Options::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Options))
        return static_cast<void*>(const_cast< Options*>(this));
    return QDialog::qt_metacast(_clname);
}

int Options::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
